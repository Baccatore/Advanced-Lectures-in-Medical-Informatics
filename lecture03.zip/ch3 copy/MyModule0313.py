#MyModule0313.py
# Author: Yuichiro SUGA
# Created: 2018-04-24
# Email: dmq0039@mail4.doshisha.ac.jp

def find(a, N):
    for x in a:
        if x == N:
            return 1
    return 0
